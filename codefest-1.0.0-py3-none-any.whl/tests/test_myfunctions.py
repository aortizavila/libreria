from codefest.un_aviso_inesperado import DetectandoCosas

entrenamiento = DetectandoCosas()
entrenamiento.TributoHeidyYolo()
entrenamiento.losDatos(directorio="data")
#entrenamiento.diasOscuros(bautiza_etiquetas=["fedex"], batch_size=4, num_experiments=200,optimizador="Adam",explicar=False)
