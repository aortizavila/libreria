import os
import time
import math
import json
import warnings
from typing import List, Union, Tuple, Dict
from collections import defaultdict

import numpy as np
from PIL import Image
import cv2
import torch
from torch.cuda import amp
from torch.utils.data import DataLoader
from torch.optim import SGD,Adam, lr_scheduler
from tqdm import tqdm

from .tools_jaguar.cebando_al_jaguar import LoadImagesAndLabels
from .tools_jaguar.localizador_presa import generate_anchors
from .tools_jaguar.compute_loss import compute_loss
from .tools_jaguar import validate
from ..yolo.tiny_yolo import YoloTiny
from ..yolo.yolo import Yolo
from ..yolo.utils import draw_bbox_and_label, get_predictions, prepare_image

from ..backend_check.model_extension import extension_check


class DetectandoCosas:
    """
    Modelo de deteccion
    """

    def __init__(self) -> None:
        if torch.cuda.is_available()==False:
          print("no vas a usar GPUs :(")
        else:
          print("Vas a usar GPUs :)")
        self.__device = "cuda" if torch.cuda.is_available() else "cpu"
        self.__cuda = (self.__device != "cpu")
        self.__model_type = ""
        self.__model = None
        self.__optimizer = None
        self.__data_dir = ""
        self.__classes: List[str] = None
        self.__num_classes = None
        self.__anchors = None
        self.__dataset_name = None
        self.__mini_batch_size: int = None
        self.__scaler = amp.GradScaler(enabled=self.__cuda)
        self.__lr_lambda = None
        self.__custom_train_dataset = None
        self.__custom_val_dataset = None
        self.__train_loader = None
        self.__val_loader = None
        self.__type_optimizer= "SGD"
        self.__model_path: str = None
        self.__epochs: int = None
        self.__output_models_dir: str = None
        self.__output_json_dir: str = None
        print("Al llamar esta clase, estas iniciando estos parametros en vacio. Parametros como")
        print("-Primero chequeamos el uso de GPU con torch.cuda.is_available()")
        print("-Tipo de modelo. Mas adelante setearemos si usamos Yolo o YoloTyni que es lo usamos para este ejemplo")
        print("-Características de la red como Optimizador, batch_size, regularizador lambda")


    def __set_training_param(self, epochs : int, accumulate : int, lr : float,momentum : float) -> None:
        # self.__lr_lambda = lambda x : ((1 - math.cos(x * math.pi / epochs)) / 2  ) * (0.1 - 1.0) + 1.0
        self.__lr_lambda = lambda x: (1 - x / (epochs - 1)) * (1.0 - 0.01) + 0.01
        self.__anchors = generate_anchors(
                                self.__custom_train_dataset,
                                n=9 if self.__model_type=="yolo" else 6,img_size=self.__net_dim[0],explicar=self.__explicar
                            )
        self.__anchors = [round(i) for i in self.__anchors.reshape(-1).tolist()]
        print("")
        print("Paso2.2 Se envían los seteados en la clase días de oscuridad a la red seleccionada.")
        if self.__model_type == "yolo":
            self.__model = Yolo(
                        num_classes=self.__num_classes,
                        anchors=self.__anchors,
                        device=self.__device,
                        height = self.__net_dim[0],
                        width = self.__net_dim[1]
                    )
        elif self.__model_type == "tiny-yolo":
            self.__model = YoloTiny(
                        num_classes=self.__num_classes,
                        anchors=self.__anchors,
                        device=self.__device,
                        height = self.__net_dim[0],
                        width = self.__net_dim[1]
                    )
        if self.__explicar==True:
          print("Esta es la arquitectura de red utilizada:")
          print(self.__model)
        if self.__model_path:
            self.__load_model()

        w_d = (5e-4) * (self.__mini_batch_size * accumulate / 64) # scale weight decay
        g0, g1, g2 = [], [], []  # optimizer parameter groups
        for m in self.__model.modules():
            if hasattr(m, 'bias') and isinstance(m.bias, torch.nn.Parameter):  # bias
                g2.append(m.bias)
            if isinstance(m, torch.nn.BatchNorm2d):  # weight (no decay)
                g0.append(m.weight)
            elif hasattr(m, 'weight') and isinstance(m.weight, torch.nn.Parameter):  # weight (with decay)
                g1.append(m.weight)

        if self.__type_optimizer=="SGD":
            self.__optimizer = SGD(
                        g0,
                        lr=lr[0],
                        momentum=momentum[0],
                        # weight_decay=w_d,
                        nesterov=True
                    )
                
        if self.__type_optimizer=="Adam":
              self.__optimizer = Adam(
                          g0,
                          lr=lr[0],
                          # weight_decay=w_d,
                          
                      ) 
        
        self.__optimizer.add_param_group({'params': g1, 'weight_decay': w_d})  # add g1 with weight_decay
        self.__optimizer.add_param_group({'params': g2})  # add g2 (biases)

        print("Paso2.3 Optimizando el aprendizado del Jaguar.")
        print("Se puede utilizar la clase LambdaLR, la cual ajusta el LR, por aca época.")
        self.__lr_scheduler = lr_scheduler.LambdaLR(
                                self.__optimizer,
                                lr_lambda=self.__lr_lambda
                            )
        del g0, g1, g2
        self.__model.to(self.__device)

    def __load_model(self) -> None:
        try:
            state_dict = torch.load(self.__model_path, map_location=self.__device)
            # check against cases where number of classes differs, causing the
            # channel of the convolutional layer just before the detection layer
            # to differ.
            new_state_dict = {k:v for k,v in state_dict.items() if k in self.__model.state_dict().keys() and v.shape==self.__model.state_dict()[k].shape}
            self.__model.load_state_dict(new_state_dict, strict=False)
        except Exception as e:
            print("La carga de los pesos preentrenados falló. Se utilizarn pesos aleatorio")
        
        print("="*20)
        print("Se carga modelo preentrenado")
        print("="*20)

    def __load_data(self) -> None:
        if self.__explicar==True:
          print("Paso1. Cebando al jaguar:")
          print("")
          print("Paso1.1. Leemos cada imagen y obtenemos:")
          print(" - Alto y ancho de la imagen.")
          print(" - Las etiquetas de cada imagen.")
          print(" - Calcula el número de fotos")
          print("")
          print("Paso1.2. Utilizando DataLoader de torch.")
          print(" En el contexto de PyTorch, DataLoader es una clase que se utiliza para cargar")
          print(" y administrar conjuntos de datos durante el entrenamiento de modelos de")
          print(" aprendizaje automático. Proporciona una interfaz conveniente para acceder a")
          print(" los datos de manera eficiente y en lotes (batches).")
          print("")
          print("Algunas de las características y funcionalidades clave del DataLoader de PyTorch son:")
          print("a. Carga eficiente de datos: El DataLoader carga los datos en paralelo")
          print("   utilizando múltiples hilos, lo que permite una carga más rápida y eficiente")
          print("   de los datos durante el entrenamiento.")
          print("b. División en lotes (batching): El DataLoader permite dividir los datos en")
          print("   lotes de un tamaño específico, lo que facilita el entrenamiento en mini lotes")
          print("   (mini-batch training). Esto es útil para ... procesar los datos en paralelo y ")
          print("   acelerar el entrenamiento.")
          print("c. Mezcla de datos (shuffling): El DataLoader puede mezclar los datos en ")
          print("   cada época (epoch) antes de dividirlos en lotes. Esto es útil para evitar")
          print("   sesgos en el entrenamiento y garantizar que el modelo vea los datos en ")
          print("   diferentes órdenes en cada época.")
          print("d.  Iteración conveniente: El DataLoader proporciona una interfaz conveniente")
          print("    para iterar sobre los datos en cada época. Puedes utilizar un bucle for para")
          print("    iterar sobre los lotes de datos y ... alimentarlos al modelo para el ")
          print("    entrenamiento.")

        self.__num_classes = len(self.__classes)
        self.__dataset_name = os.path.basename(os.path.dirname(self.__data_dir+os.path.sep))
        self.__custom_train_dataset = LoadImagesAndLabels(self.__data_dir,net_dim=self.__net_dim, train=True)
        self.__custom_val_dataset = LoadImagesAndLabels(self.__data_dir,net_dim=self.__net_dim, train=False)

        self.__train_loader = DataLoader(
                            self.__custom_train_dataset, batch_size=self.__mini_batch_size,
                            shuffle=True,
                            collate_fn=self.__custom_train_dataset.collate_fn
                        )
        self.__val_loader = DataLoader(
                            self.__custom_val_dataset, batch_size=self.__mini_batch_size//2,
                            shuffle=True, collate_fn=self.__custom_val_dataset.collate_fn
                        )

    def TributoHeidyYolo(self) -> None:
        """
        Seleciona el tipo de modelo yolov3.
        :return:
        """
        self.__model_type = "yolo"
        print("seleccionaste al tributo Heidy Yolo. Seteamos la variale TipoModelo para usar una arquitectura yolo")

    def TributoCarlosYoloTiny(self) -> None:
        """
        Seleciona el tipo de modelo Tinyyolov3.
        :return:
        """
        self.__model_type = "tiny-yolo"
        print("seleccionaste al tributo Carlos YoloTiny.. Seteamos la variale TipoModelo para usar una arquitectura yolo tiny")

    def losDatos(self, directorio: str):
        """
        Se requiere 'losDatos()' para establecer la ruta en la que se guardan los datos/conjunto de datos que se utilizarán para el entrenamiento. El conjunto de datos de entrada debe estar en formato YOLO. El directorio puede tener cualquier nombre, pero debe tener 'train' y 'validation'
         subdirectorio. En los subdirectorios 'tren' y 'validación' debe haber 'imágenes' y 'anotaciones'
         subdirectorios respectivamente. La carpeta 'imágenes' contendrá las imágenes del conjunto de datos y el
         La carpeta 'anotaciones' contendrá los archivos TXT con detalles de las anotaciones para cada imagen en el
         'carpeta de imágenes'.
         N.B: tenga estrictamente en cuenta que los nombres de archivo (sin la extensión) de las imágenes en la 'carpeta de imágenes'
         debe ser el mismo que los nombres de archivo (excepto la extensión) de sus archivos TXT de anotación correspondientes en
         la carpeta 'anotaciones'.
         La estructura de la carpeta 'entrenamiento' y 'validación' debe ser la siguiente:
             >> train >> imágenes >> img_1.jpg
                         >> imágenes >> img_2.jpg
                         >> imágenes >> img_3.jpg
                         >> anotaciones >> img_1.txt
                         >> anotaciones >> img_2.txt
                         >> anotaciones >> img_3.txt
             >> test     >> imágenes >> img_151.jpg
                             >> imágenes >> img_152.jpg
                             >> imágenes >> img_153.jpg
                             >> anotaciones >> img_151.txt
                             >> anotaciones >> img_152.txt
                             >> anotaciones >> img_153.txt
         :param directorio_datos:
         :devolver:
        """
        if os.path.isdir(directorio):
            self.__data_dir = directorio
            print("Tus datos estan en el directorio "+directorio)
            print(" La estructura de carpetas y subcarpetas que hemos elegido es:")
            print("   train/imagenes/")
            print("   train/etiquetas/")
            print("   test/imagenes/")
            print("   test/etiquetas/")
            print("Recuerda entonces que así debes nombrar tus carpetas. En imagenes van las imagenes que seleccionaste para entrenar. En etiquetas va tu archivo plano. Es un archivo por cada imagen")

        else:
            raise ValueError(
                    "Revisa tu dictorio, parece no existir"
                )
    def diasOscuros(self, bautiza_etiquetas: List[str], batch_size: int=4, num_experiments=100, construir_sobre_construido: str = None, optimizador:str = "SGD",lr=0.001,momentum=0.6,net_dim=(416, 416),validar=False,explicar=False):
        """
        'diasOscuros()' La función le permite establecer las propiedades de las instancias de entrenamiento. Acepta los siguientes valores:
         - bautiza_etiquetas, esta es una matriz de los nombres de los diferentes objetos en su conjunto de datos, en el orden del índice se anota su conjunto de datos
         - batch_size (opcional), este es el tamaño del batch para la instancia de entrenamiento
         - num_experiments (opcional), también conocido como épocas, es la cantidad de veces que la red entrenará en todo el conjunto de datos de entrenamiento.
         - construir_sobre_construido (opcional), se utiliza para realizar transferencia de aprendizaje especificando la ruta a un modelo YOLO o TinyYOLO previamente entrenado
         :param bautiza_etiquetas:
         :param tamaño_lote:
         :param num_experimentos:
         :param 
         :param construir_sobre_construido:
         :devolver:
        """
        self.__model_path = construir_sobre_construido
        if self.__model_path:
            extension_check(self.__model_path)
        self.__classes = bautiza_etiquetas
        self.__mini_batch_size = batch_size
        self.__epochs = num_experiments
        self.__type_optimizer = optimizador
        self.__lr=lr,
        self.__momentum=momentum,
        self.__net_dim=net_dim[0],net_dim[1],
        self.__output_models_dir = os.path.join(self.__data_dir, "models")
        self.__output_json_dir = os.path.join(self.__data_dir, "json")
        self.__validar=validar
        self.__explicar=explicar
        if explicar==True:
          print("Acá se estan configurando algunos parametros básicos para entrenar")
          print("- Nombre que le vas a dar las etiquetas: ",self.__classes)
          print("- batch_size: ",self.__mini_batch_size, " Número de ejemplos de entrenamiento que se propagan a través de la red en una sola iteración.")
          print("- Epocas: ",self.__epochs, " Número de iteraciones")
          print("- Opimizador= ",self.__type_optimizer, "Selección optimizador")
          print("- Learning Rate: ", self.__lr," Que tanto rápido aprende el Jaguar")
          print("- Momentum: ",self.__momentum, "Que tanto influye el gradiente en la busqueda de mínimos locales")
          print("- Dimensión de entrada de la red: ",self.__net_dim)
          print("- Si vas a construir sobre lo construido: ",self.__model_path)
          print("- Acá se van a guardar tus modelos: ",os.path.join(self.__data_dir, "models"))
          print("- Acá puedes encontrar un archivo json donde tiene la etiqueta con la descripción: ",os.path.join(self.__data_dir, "json"))

    def batalla_del_Jaguar(self) -> None:
        """
        La función 'trainModel()' inicia el entrenamiento del modelo real. Una vez que comienza la capacitación, la instancia de capacitación
         crea 3 subcarpetas en su carpeta de conjunto de datos que son:
         - json, donde se almacena el archivo de configuración JSON para usar su modelo entrenado
         - modelos, donde se almacenan los modelos entrenados una vez que se generan después de cada experimento mejorado
         - caché, donde se almacenan los archivos de configuración de entrenamiento temporales        :return:
        """
        if self.__explicar==True:
            print("Función que nos permite entrenar el modelo. Se surtiran los siguientes pasos: ")
        self.__load_data()
        os.makedirs(self.__output_models_dir, exist_ok=True)
        os.makedirs(self.__output_json_dir, exist_ok=True)

        mp, mr, map50, map50_95, best_fitness = 0, 0, 0, 0, 0.0
        nbs = 64 # norminal batch size
        nb = len(self.__train_loader) # number of batches
        nw = max(3 * nb, 1000)  # number of warmup iterations.
        last_opt_step = -1
        prev_save_name, recent_save_name = "", ""

        accumulate = max(round(nbs / self.__mini_batch_size), 1) # accumulate loss before optimizing.

        if self.__explicar==True:
          print("")
          print("")
          print("Paso2. Equipando el jaguar. Setear los hiperparámetros de la red:")
        self.__set_training_param(self.__epochs, accumulate,self.__lr,self.__momentum)

        with open(os.path.join(self.__output_json_dir, f"{self.__dataset_name}_{self.__model_type}_detection_config.json"), "w") as configWriter:
            json.dump(
                {
                    "labels": self.__classes,
                    "anchors": self.__anchors
                },
                configWriter
            )

        since = time.time()

        self.__lr_scheduler.last_epoch = -1

        for epoch in range(1, self.__epochs+1):
            self.__optimizer.zero_grad()
            mloss = torch.zeros(3, device=self.__device)
            print(f"Epoch {epoch}/{self.__epochs}", "-"*10, sep="\n")

            for phase in ["train", "test"]:
                if phase=="train":
                    self.__model.train()
                    print("Train: ")
                    for batch_i, (data, anns) in tqdm(enumerate(self.__train_loader)):
                        batches_done = batch_i + nb * epoch

                        data = data.to(self.__device)
                        anns = anns.to(self.__device)

                        # warmup
                        if batches_done <= nw:
                            xi = [0, nw]  # x interp
                            accumulate = max(1, np.interp(batches_done, xi, [1, nbs / self.__mini_batch_size]).round())
                            for j, x in enumerate(self.__optimizer.param_groups):
                                # bias lr falls from 0.1 to lr0, all other lrs rise from 0.0 to lr0
                                x['lr'] = np.interp(batches_done, xi, [0.1 if j == 2 else 0.0, 0.01 * self.__lr_lambda(epoch)])
                                if 'momentum' in x:
                                    x['momentum'] = np.interp(batches_done, xi, [0.8, 0.9])

                        with amp.autocast(enabled=self.__cuda):
                            _ = self.__model(data)
                            loss_layers = self.__model.get_loss_layers()
                            loss, loss_components = compute_loss(loss_layers, anns.detach(), self.__device)

                        self.__scaler.scale(loss).backward()
                        mloss = (mloss * batch_i + loss_components) / (batch_i + 1)

                       # Optimize
                        if batches_done - last_opt_step >= accumulate:
                            self.__scaler.step(self.__optimizer)  # optimizer.step
                            self.__scaler.update()
                            self.__optimizer.zero_grad()
                            last_opt_step = batches_done

                    print(f"    box loss-> {float(mloss[0]):.5f}, object loss-> {float(mloss[1]):.5f}, class loss-> {float(mloss[2]):.5f}")

                    self.__lr_scheduler.step()
                
                if self.__validar==True:
                    self.__model.eval()
                    print("test:")

                    mp, mr, map50, map50_95 = validate.run(
                                                self.__model, self.__val_loader,
                                                self.__num_classes, device=self.__device
                                            )
                    
                    print(f"    recall: {mr:0.6f} precision: {mp:0.6f} mAP@0.5: {map50:0.6f}, mAP@0.5-0.95: {map50_95:0.6f}" "\n")

                    if map50 > best_fitness:
                        best_fitness = map50
                        recent_save_name = self.__model_type+f"_{self.__dataset_name}_mAP-{best_fitness:0.5f}_epoch-{epoch}.pt"
                        if prev_save_name:
                            os.remove(os.path.join(self.__output_models_dir, prev_save_name))
                        torch.save(
                            self.__model.state_dict(),
                            os.path.join(self.__output_models_dir, recent_save_name)
                        )
                        prev_save_name = recent_save_name
                  

            if epoch == self.__epochs:
                torch.save(
                        self.__model.state_dict(),
                        os.path.join(self.__output_models_dir, self.__model_type+f"_{self.__dataset_name}_last_model.pt")
                    )

        elapsed_time = time.time() - since
        print(f"El entrenamiento tomó {elapsed_time//60:.0f}m {elapsed_time % 60:.0f}s")
        torch.cuda.empty_cache()

