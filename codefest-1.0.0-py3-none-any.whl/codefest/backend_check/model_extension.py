import os

def extension_check(file_path: str):
    if file_path.endswith(".h5"):
        raise RuntimeError("So soportamos arhivo h5 sino pt. La razón es que no usamos tensorflow sino pytorch")
    elif file_path.endswith(".pt") == False and file_path.endswith(".pth") == False:
        raise ValueError(f"Archivo invalido {os.path.basename(file_path)}. Use un archivo '.pt' o '.pth' para el modelo.")
